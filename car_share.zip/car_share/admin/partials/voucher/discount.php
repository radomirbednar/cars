<input type="number" step="0.1" name="_discount" value="<?php echo $discount ?>">

