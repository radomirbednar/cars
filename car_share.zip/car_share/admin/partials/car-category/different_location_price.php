<table>
    <tr>
        <td>
            <?php _e('Price:', $this->car_share) ?>
        </td>
        <td>
            <input type="number" name="_location_price" value="<?php echo floatval($location_price) ?>" >
        </td>
    </tr>
    <!--
    <tr>
        <td>
            <?php _e('Apply:', $this->car_share) ?>
        </td>
        <td>
            <input type="checkbox" name="_apply_location_price" value="1" >
        </td>
    </tr>    -->
</table>

