<div class="postbox " id="single_car_box_<?php echo $car_id ?>">
    <div title="Click to toggle" class="handlediv"><br></div><h3 class="hndle ui-sortable-handle"><span><?php _e('Single car', $this->car_share) ?> #<?php echo $label ?></span></h3>
        <div class="inside">    
        <?php include 'single_car.php'; ?>
        <div class="clear"></div>
    </div>
</div>
